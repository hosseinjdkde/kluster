package main

import (
	"fmt"
	"github.com/viveksinghggits/kluster/pkg/apis/viveksingh.dev/v1alpha1"
)

func main() {
	k := v1alpha1.Kluster
	fmt.Println(k)
}
