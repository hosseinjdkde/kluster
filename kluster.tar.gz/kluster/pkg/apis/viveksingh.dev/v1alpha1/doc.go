// +k8s:deepcopy-gen=package
// +k8s:defaulter-gen=TypeMeta
// +groupName=viveksingh.dev

package v1alpha1
